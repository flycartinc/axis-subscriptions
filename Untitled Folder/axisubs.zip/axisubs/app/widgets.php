<?php namespace Axisubs;

/** @var \Herbert\Framework\Widget $widget */
