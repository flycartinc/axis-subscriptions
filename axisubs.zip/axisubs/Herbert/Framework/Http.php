<?php namespace Herbert\Framework;

use Illuminate\Http\Request;

/**
 * @see http://getherbert.com
 */
class Http extends Request {

    //

}
