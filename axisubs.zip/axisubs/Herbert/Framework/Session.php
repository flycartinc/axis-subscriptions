<?php namespace Herbert\Framework;

use Symfony\Component\HttpFoundation\Session\Session as BaseSession;

class Session extends BaseSession {

    //

}
